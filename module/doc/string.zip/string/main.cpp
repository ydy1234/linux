#include <iostream>
#include "_stringv2.h"

using std::cin;
using std::cout;
using std::cin;
using std::endl;

int main()
{
    String s1;
    s1 = "abc";
    {
        String s2(s1);
        s2 += s1;
        cout << s2 << endl;
    }
    String s3(s1);
    cin >> s3;
    cout << s3 << endl;
    cout << s1 << endl;
    String s4 = s1 + s3;
    cout << s4 << endl;
}
